<!doctype html>
<html>
<head> <!---recuerda cerrar--->

<link rel="stylesheet" href="ejer1.css"> 
</head>
<body><!---recuerda cerrar--->

<?php
 
$valor1 = 0;
$valor2 = 0;
$a=[];
$b=[];

print "<h1>jugador 1</h1>";
for($i=0; $i <6; $i++){
	$valor1=rand(1,6);
	$a[$i]=$valor1;
	print "<img src='./img/$a[$i].jpg' width=100 height=100>\n";
	$suma1+=$valor1; // $suma = $valor + $suma
}

print "<h1>jugador 2</h1>";
for($e=1; $e <=6; $e++){
	$valor2=rand(1,6);
	$b[$e]=$valor2;
	print "<img src=./img/$b[$e].jpg width=100 height=100>\n";
	$suma2+=$valor2;
}
print "<br><br><br><br>";
if($suma1 > $suma2){
	
print "jugador1 gana";
}
else{
	print "jugador2 gana";
}

?>
</body>
</html>