<!doctype html>
<html>
<head> <!---recuerda cerrar--->
</head>
<body><!---recuerda cerrar--->
<form action="ancho.php" method="post">
    <p>Alto: <input type="text" name="alto"></p>
	<p>Ancho: <input type="text" name="ancho"></p>
    <p><input type="submit" value="Dibujar"></p>
</form>
</body>
</html>