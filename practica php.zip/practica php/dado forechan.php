<!doctype html>
<html>
<head> <!---recuerda cerrar--->
</head>
<body><!---recuerda cerrar--->

<?php
 
$valor = 0;
$a=[];


for($i=0; $i <=6; $i++){
	$valor=rand(1,6);
	$a[$i]=$valor;
	print "<img src='./img/$a[$i].jpg' width=100 height=100>\n";
}
for($k=0;$k<=6;$k++)
{
	print "$a[$k]<br>";
}

	

	


?>
</body>
</html>