<?php 
$alto= trim(strip_tags($_REQUEST["alto"]));
$ancho= trim(strip_tags($_REQUEST["ancho"]));
if( 0 >= $alto || $alto > 100){
	echo "no puede ser menor que 0 ni mayor que 100";
}
else{
if(0 >= $ancho || $ancho > 100){
	echo "no puede ser menor que 0 ni mayor que 100";
}
else{
$b=0;
$a=0;
while($b <$alto) {
	$b++;
		while($a <$ancho) {
			print"*";
			$a++;	
		}
		$a=0;
	print "<br>";
	}
	}
}	

?>