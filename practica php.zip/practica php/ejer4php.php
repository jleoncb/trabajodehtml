<?php
$nombre = $_POST['nombre'];
$trabajo = $_POST['trabajo'];
$telefono = $_POST['telefono'];
$direccion = $_POST['direcion'];
$otras = $_POST['otras'];
$bus = $_POST['bus'];
$boton = $_POST['boton'];
$file = "agenda.txt";



if ($boton == "guardar") {
	if(trim($nombre)=='' || trim($trabajo)=='' || trim($telefono)=='' || trim($direccion)=='' || trim($otras)==''){
     echo'<script type="text/javascript">
     alert("algún campo esta vacío");
     window.location.href="ejer4.html";
    </script>';
    }
if (!is_numeric($telefono)){
	echo'<script type="text/javascript">
	alert("el formato del teléfono es incorrecto");
    window.location.href="ejer4.html";
    </script>';
    }
else {
$archivo = fopen($file, "a");
$var = "Contacto: $nombre $trabajo $telefono $direccion $otras" .PHP_EOL;
fwrite($archivo,$var );
fclose($archivo);
echo'<script type="text/javascript">
window.location.href="ejer4.html";
</script>';
    }
}

if ($boton == "mostrar") {
$archivo = fopen($file, "r");

while (!feof($archivo)) {
echo fgets($archivo) . "<br>";
}
    
fclose($archivo);
   
}

if ($boton == "buscar") {
    if (trim($bus)=='') {
        echo'<script type="text/javascript">
        alert("No se puede buscar si el nombre esta vacío");
        window.location.href="ejer4.html";
		</script>';
}

else {
	$archivo = fopen($file, "r");
    $encontrado = false;
    while (!feof($archivo)) {
        $line = fgets($archivo);
        if (strpos($line,"Contacto: $bus" ) !== false) {
            echo  $line."<br>";
            $encontrado = true;
        }
}
}
    fclose($archivo);
	
if (!$encontrado) {
    echo'<script type="text/javascript">
    alert("No se eoncntraron resultados para el nombre indicado.  Se le va a redirigir al fromulario 🫡");
    window.location.href="ejer4.html";
	</script>';
    }
}
?>